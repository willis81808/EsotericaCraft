package com.darksundev.esotericacraft.items;

import net.minecraft.item.Item;

public class DiamondDust extends Item
{

	public DiamondDust(Properties properties) 
	{
		super
		(
			properties.maxStackSize(64)
		);
	}

}
