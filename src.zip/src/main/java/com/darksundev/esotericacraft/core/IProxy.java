package com.darksundev.esotericacraft.core;

public interface IProxy
{
	public void init();
}
